import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route for Gemini Financial Advisor
  app.post("/api/gemini/generate", async (req, res) => {
    try {
      const { prompt, invoices } = req.body;
      if (!prompt) {
        return res.status(400).json({ error: "Prompt is required" });
      }

      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "Sistemde GEMINI_API_KEY yapılandırılmamış. Lütfen Settings > Secrets bölümünden anahtarınızı ekleyin." });
      }

      const ai = new GoogleGenAI({
        apiKey: apiKey,
        httpOptions: {
          headers: {
            'User-Agent': 'aistudio-build',
          }
        }
      });

      // Format invoices into a readable block for the AI model
      const invoicesContext = Array.isArray(invoices) 
        ? invoices.map((inv, index) => 
            `${index + 1}. Firma: ${inv.companyName}, Tutar: ${inv.amount.toLocaleString('tr-TR')} TL, Vade Tarihi: ${inv.dueDate}, Durum: ${inv.status}, Ödeme Sözü Tarihi: ${inv.promiseDate || 'Belirtilmedi'}, Ödeme Sözü Tutarı: ${inv.promiseAmount ? inv.promiseAmount.toLocaleString('tr-TR') + ' TL' : 'Belirtilmedi'}, Telefon: ${inv.phone || 'Girilmedi'}, Notlar: ${inv.notes || 'Yok'}`
          ).join('\n')
        : "Hiç cari vade kaydı bulunmuyor.";

      const systemInstruction = `Sen, muhasebe ofisleri ve finans yöneticileri için çalışan çok yetenekli bir 'AI Danışman (Finansal Asistan)' yapay zeka modelisin. 
Sana sağlanan güncel cari vade ve fatura verilerini analiz ederek, profesyonel, yapıcı, net ve işe yarar finansal tavsiyeler vermeli ve raporlar hazırlamalısın.

Mevcut Sistem Tarihi: 2026-07-20

Aşağıdaki güncel cari kayıtları ve faturalar veritabanından dinamik olarak çekilmiştir:
[CARİ VERİLERİ]
${invoicesContext}
[/CARİ VERİLERİ]

Senden yanıtlarını hazırlarken şu kurallara uyman beklenir:
1. Türkçe dilinde yanıt ver.
2. Yanıtlarında Markdown biçimlendirmesini (kalın yazılar, listeler, tablolar) son derece şık ve okunabilir bir şekilde kullan.
3. Finansal analiz yaparken matematiksel doğruluğa %100 dikkat et.
4. "Bu ay en acil aranması gereken 5 firma kim?" sorusunda vadesi geçmiş veya vadesine çok az kalmış, tutarı yüksek ve ödeme sözü alınmamış/vadesi geçmiş firmaları analiz et. Telefon numarası olanları belirt.
5. "Geciken alacaklar için müşteriye gönderebileceğim kibar bir uyarı metni yaz" dendiğinde, faturası gecikmiş firmaların verilerini kullanarak her biri için doğrudan kopyalanıp WhatsApp'tan veya SMS'ten atılabilecek, samimi, kibar ama net mesaj şablonları oluştur.
6. Muhasebeci dilini koru; sade, profesyonel ve çözüm odaklı ol.`;

      const response = await ai.models.generateContent({
        model: "gemini-3.5-flash",
        contents: prompt,
        config: {
          systemInstruction: systemInstruction,
          temperature: 0.7,
        }
      });

      res.json({ text: response.text });
    } catch (error: any) {
      console.error("Gemini API Error:", error);
      res.status(500).json({ error: error.message || "Yapay zeka yanıtı üretilirken sunucu tarafında bir hata oluştu." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
