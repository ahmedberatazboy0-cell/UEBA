import React, { useState } from 'react';
import { Invoice, FilterOptions, StatusFilterType, DueFilterType, InvoiceStatus } from '../types';
import { getDueStatus, getDaysRemainingText, CURRENT_DATE_STR, safeParseDate } from '../data';
import { Search, Edit2, Trash2, CheckCircle2, AlertTriangle, Clock, XCircle, ArrowUpDown, Filter, ChevronDown, RefreshCw, MessageCircle, Phone } from 'lucide-react';

interface InvoiceTableProps {
  invoices: Invoice[];
  onEdit: (invoice: Invoice) => void;
  onDelete: (id: string) => void;
  onStatusChange: (id: string, newStatus: InvoiceStatus) => void;
  activeQuickFilter: string;
}

export const InvoiceTable: React.FC<InvoiceTableProps> = ({
  invoices,
  onEdit,
  onDelete,
  onStatusChange,
  activeQuickFilter
}) => {
  // Filters state
  const [filters, setFilters] = useState<FilterOptions>({
    search: '',
    status: 'hepsi',
    dueStatus: 'hepsi',
    minAmount: '',
    maxAmount: '',
    sortBy: 'dueDate-asc'
  });

  // State to toggle advanced filters panel
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Formatting helpers
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(val);
  };

  const formatDate = (dateStr: string) => {
    return safeParseDate(dateStr).toLocaleDateString('tr-TR', {
      year: 'numeric',
      month: '2-digit',
      day: '2-digit'
    });
  };

  // WhatsApp helper utilities
  const cleanPhone = (phoneStr: string) => {
    const cleaned = phoneStr.replace(/\D/g, ''); // Sadece rakamları tut
    if (!cleaned) return '';
    // Türkiye cep numarası formatlama (5xx xxx xx xx -> 905xxxxxxxxx)
    if (cleaned.length === 10 && cleaned.startsWith('5')) {
      return '90' + cleaned;
    }
    if (cleaned.length === 11 && cleaned.startsWith('05')) {
      return '90' + cleaned.substring(1);
    }
    return cleaned;
  };

  const getWhatsAppLink = (inv: Invoice) => {
    if (!inv.phone) return '#';
    const cleanNum = cleanPhone(inv.phone);
    const formattedAmount = inv.amount.toLocaleString('tr-TR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    
    // Tarihi GG.AA.YYYY olarak biçimlendir
    let trDate = inv.dueDate;
    try {
      const parts = inv.dueDate.split('-');
      if (parts.length === 3) {
        trDate = `${parts[2]}.${parts[1]}.${parts[0]}`;
      }
    } catch (e) {}

    const textMessage = `Sayın ${inv.companyName}, ${trDate} vadeli ${formattedAmount} TL tutarındaki ödemenizi hatırlatmak isteriz. İyi çalışmalar dileriz.`;
    return `https://wa.me/${cleanNum}?text=${encodeURIComponent(textMessage)}`;
  };

  // Filter and sort invoices
  const filteredInvoices = invoices.filter(inv => {
    // Search filter
    const matchesSearch = 
      inv.companyName.toLowerCase().includes(filters.search.toLowerCase()) ||
      (inv.notes && inv.notes.toLowerCase().includes(filters.search.toLowerCase()));

    // Status filter
    const matchesStatus = filters.status === 'hepsi' || inv.status === filters.status;

    // Due status filter
    const dueState = getDueStatus(inv.dueDate, inv.status);
    let matchesDue = true;
    if (filters.dueStatus === 'vadesi-gecen') {
      matchesDue = dueState === 'overdue';
    } else if (filters.dueStatus === 'vadesi-yaklasan') {
      matchesDue = dueState === 'upcoming';
    } else if (filters.dueStatus === 'vadesi-gelen') {
      matchesDue = dueState === 'normal';
    }

    // Amount range filter
    const numericMin = parseFloat(filters.minAmount);
    const numericMax = parseFloat(filters.maxAmount);
    const matchesMinAmount = isNaN(numericMin) || inv.amount >= numericMin;
    const matchesMaxAmount = isNaN(numericMax) || inv.amount <= numericMax;

    // Apply quick filter from dashboard header
    let matchesQuickFilter = true;
    if (activeQuickFilter === 'overdue') {
      matchesQuickFilter = dueState === 'overdue';
    } else if (activeQuickFilter === 'upcoming') {
      matchesQuickFilter = dueState === 'upcoming';
    } else if (activeQuickFilter === 'pending') {
      matchesQuickFilter = inv.status === 'Bekliyor' && dueState === 'normal';
    } else if (activeQuickFilter === 'paid') {
      matchesQuickFilter = inv.status === 'Ödendi';
    }

    return matchesSearch && matchesStatus && matchesDue && matchesMinAmount && matchesMaxAmount && matchesQuickFilter;
  });

  // Sort
  const sortedInvoices = [...filteredInvoices].sort((a, b) => {
    if (filters.sortBy === 'dueDate-asc') {
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    }
    if (filters.sortBy === 'dueDate-desc') {
      return new Date(b.dueDate).getTime() - new Date(a.dueDate).getTime();
    }
    if (filters.sortBy === 'amount-asc') {
      return a.amount - b.amount;
    }
    if (filters.sortBy === 'amount-desc') {
      return b.amount - a.amount;
    }
    if (filters.sortBy === 'companyName-asc') {
      return a.companyName.localeCompare(b.companyName, 'tr');
    }
    return 0;
  });

  const handleResetFilters = () => {
    setFilters({
      search: '',
      status: 'hepsi',
      dueStatus: 'hepsi',
      minAmount: '',
      maxAmount: '',
      sortBy: 'dueDate-asc'
    });
  };

  return (
    <div className="space-y-4">
      
      {/* 1. Control & Filter Panel */}
      <div className="bg-white rounded-2xl border border-slate-100 p-5 shadow-xs space-y-4">
        <div className="flex flex-col md:flex-row gap-3">
          {/* Search box */}
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              placeholder="Firma adı veya faturaya dair notlarda arama yapın..."
              value={filters.search}
              onChange={(e) => setFilters({ ...filters, search: e.target.value })}
              className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-slate-800 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all bg-slate-50/50"
            />
          </div>

          {/* Quick status filter select */}
          <div className="flex gap-2">
            <select
              value={filters.status}
              onChange={(e) => setFilters({ ...filters, status: e.target.value as StatusFilterType })}
              className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-medium cursor-pointer"
            >
              <option value="hepsi">Tüm Durumlar</option>
              <option value="Bekliyor">Bekliyor</option>
              <option value="Ödendi">Ödendi</option>
              <option value="İptal Edildi">İptal Edildi</option>
            </select>

            <select
              value={filters.sortBy}
              onChange={(e) => setFilters({ ...filters, sortBy: e.target.value as any })}
              className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-700 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 font-medium cursor-pointer"
            >
              <option value="dueDate-asc">Vade: Yakından Uzağa</option>
              <option value="dueDate-desc">Vade: Uzaktan Yakına</option>
              <option value="amount-desc">Tutar: Azalan</option>
              <option value="amount-asc">Tutar: Artan</option>
              <option value="companyName-asc">Firma Adı (A-Z)</option>
            </select>

            <button
              onClick={() => setShowAdvanced(!showAdvanced)}
              className={`px-4 py-2.5 rounded-xl border text-sm font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
                showAdvanced 
                  ? 'bg-slate-900 text-white border-slate-900' 
                  : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
              }`}
            >
              <Filter className="w-4 h-4" />
              Gelişmiş
            </button>
          </div>
        </div>

        {/* Advanced Filters Drawer */}
        {showAdvanced && (
          <div className="pt-3 border-t border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-4 animate-in fade-in duration-150">
            {/* Due Timeline Filter */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600">Vade Durumu</label>
              <select
                value={filters.dueStatus}
                onChange={(e) => setFilters({ ...filters, dueStatus: e.target.value as DueFilterType })}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              >
                <option value="hepsi">Tüm Vadeler</option>
                <option value="vadesi-gecen">Gecikenler (Kırmızı)</option>
                <option value="vadesi-yaklasan">Yaklaşanlar (Sarı)</option>
                <option value="vadesi-gelen">Gelecek Vadeli (Bekleyen)</option>
              </select>
            </div>

            {/* Min Amount */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600">Min. Tutar (₺)</label>
              <input
                type="number"
                placeholder="Örn: 5000"
                value={filters.minAmount}
                onChange={(e) => setFilters({ ...filters, minAmount: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
              />
            </div>

            {/* Max Amount */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-600">Max. Tutar (₺)</label>
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder="Örn: 20000"
                  value={filters.maxAmount}
                  onChange={(e) => setFilters({ ...filters, maxAmount: e.target.value })}
                  className="w-full px-3 py-2 rounded-lg border border-slate-200 text-xs text-slate-700 bg-white focus:outline-hidden focus:ring-1 focus:ring-indigo-500"
                />
                <button
                  onClick={handleResetFilters}
                  className="px-2.5 bg-slate-100 hover:bg-slate-200 rounded-lg text-slate-600 text-xs font-bold transition-colors flex items-center justify-center cursor-pointer"
                  title="Filtreleri Temizle"
                >
                  <RefreshCw className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Filter Summary Tags */}
        {(filters.search || filters.status !== 'hepsi' || filters.dueStatus !== 'hepsi' || filters.minAmount || filters.maxAmount || activeQuickFilter !== 'all') && (
          <div className="flex flex-wrap gap-2 items-center text-xs text-slate-500 pt-1">
            <span className="font-semibold">Aktif Süzgeçler:</span>
            {filters.search && (
              <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md font-medium">Arama: "{filters.search}"</span>
            )}
            {filters.status !== 'hepsi' && (
              <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md font-medium">Durum: {filters.status}</span>
            )}
            {filters.dueStatus !== 'hepsi' && (
              <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md font-medium">Vade: {
                filters.dueStatus === 'vadesi-gecen' ? 'Gecikenler' : filters.dueStatus === 'vadesi-yaklasan' ? 'Yaklaşanlar' : 'Gelecek'
              }</span>
            )}
            {(filters.minAmount || filters.maxAmount) && (
              <span className="bg-slate-100 text-slate-700 px-2.5 py-1 rounded-md font-medium">
                Tutar: {filters.minAmount || '0'} - {filters.maxAmount || '∞'} ₺
              </span>
            )}
            {activeQuickFilter !== 'all' && (
              <span className="bg-indigo-50 text-indigo-700 px-2.5 py-1 rounded-md font-semibold">
                Kart Filtresi: {
                  activeQuickFilter === 'overdue' ? 'Vadesi Geçen' : activeQuickFilter === 'upcoming' ? 'Vadesi Yaklaşan' : activeQuickFilter === 'pending' ? 'Bekleyen' : 'Ödenen'
                }
              </span>
            )}
            <button 
              onClick={handleResetFilters}
              className="text-indigo-600 hover:text-indigo-800 font-bold hover:underline ml-auto cursor-pointer"
            >
              Filtreleri Temizle
            </button>
          </div>
        )}
      </div>

      {/* 2. Main Responsive Invoice Table */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            
            {/* Table Head */}
            <thead className="bg-slate-50 text-slate-500 text-xs font-semibold uppercase tracking-wider border-b border-slate-100">
              <tr>
                <th className="px-6 py-4">Firma Adı & Notlar</th>
                <th className="px-6 py-4">Fatura Tutarı</th>
                <th className="px-6 py-4">Vade Tarihi</th>
                <th className="px-6 py-4">Telefon / WhatsApp</th>
                <th className="px-6 py-4">Ödeme Sözü</th>
                <th className="px-6 py-4">Kalan Süre / Durum Analizi</th>
                <th className="px-6 py-4 text-center">Ödeme Durumu</th>
                <th className="px-6 py-4 text-right">Eylemler</th>
              </tr>
            </thead>

            {/* Table Body */}
            <tbody className="divide-y divide-slate-100">
              {sortedInvoices.length > 0 ? (
                sortedInvoices.map((inv) => {
                  const dueState = getDueStatus(inv.dueDate, inv.status);
                  const remaining = getDaysRemainingText(inv.dueDate, inv.status);

                  // Check if payment promise date has passed today (2026-07-20) and status is not Ödendi
                  const isPromiseOverdue = inv.status === 'Bekliyor' && inv.promiseDate && safeParseDate(inv.promiseDate) < safeParseDate(CURRENT_DATE_STR);

                  // Determine row design background based on due warnings
                  let rowBgClass = 'hover:bg-slate-50/50';
                  let borderIndicator = '';
                  
                  if (isPromiseOverdue) {
                    rowBgClass = 'bg-rose-100 hover:bg-rose-100/90 text-rose-950 font-medium';
                    borderIndicator = 'border-l-4 border-l-rose-600';
                  } else if (inv.status === 'Bekliyor') {
                    if (dueState === 'overdue') {
                      rowBgClass = 'bg-rose-50/30 hover:bg-rose-50/50';
                      borderIndicator = 'border-l-4 border-l-rose-500';
                    } else if (dueState === 'upcoming') {
                      rowBgClass = 'bg-amber-50/20 hover:bg-amber-50/40';
                      borderIndicator = 'border-l-4 border-l-amber-500';
                    }
                  } else if (inv.status === 'Ödendi') {
                    rowBgClass = 'bg-emerald-50/10 hover:bg-emerald-50/20';
                    borderIndicator = 'border-l-4 border-l-emerald-500';
                  }

                  return (
                    <tr 
                      key={inv.id} 
                      id={`invoice-row-${inv.id}`}
                      className={`transition-colors duration-150 ${rowBgClass} ${borderIndicator}`}
                    >
                      {/* Company Name & Notes */}
                      <td className="px-6 py-4.5">
                        <div className="font-semibold text-slate-900">{inv.companyName}</div>
                        {inv.notes && (
                          <div className="text-xs text-slate-400 mt-1 max-w-sm truncate" title={inv.notes}>
                            {inv.notes}
                          </div>
                        )}
                      </td>

                      {/* Amount */}
                      <td className="px-6 py-4.5">
                        <span className="font-mono font-bold text-slate-800 text-sm">
                          {formatCurrency(inv.amount)}
                        </span>
                      </td>

                      {/* Due Date */}
                      <td className="px-6 py-4.5">
                        <div className="text-slate-700 text-sm font-medium font-mono flex items-center gap-1.5">
                          {formatDate(inv.dueDate)}
                        </div>
                      </td>

                      {/* Phone / WhatsApp Column */}
                      <td className="px-6 py-4.5">
                        {inv.phone ? (
                          <div className="space-y-1.5">
                            <div className="text-xs text-slate-700 font-medium font-mono flex items-center gap-1">
                              <Phone className="w-3.5 h-3.5 text-slate-400" />
                              {inv.phone}
                            </div>
                            <a
                              href={getWhatsAppLink(inv)}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-500 hover:bg-emerald-600 active:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-xs transition-colors cursor-pointer"
                              title="WhatsApp Web veya Mobil Uygulaması ile Hatırlat"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              WhatsApp Hatırlat
                            </a>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            <div className="text-xs text-slate-400 italic">Telefon Yok</div>
                            <button
                              onClick={() => onEdit(inv)}
                              className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold hover:underline cursor-pointer flex items-center gap-0.5"
                              title="Telefon numarası ekle"
                            >
                              + Telefon Ekle
                            </button>
                          </div>
                        )}
                      </td>

                      {/* Payment Promise (Ödeme Sözü) Column */}
                      <td className="px-6 py-4.5">
                        {inv.promiseDate ? (
                          inv.status === 'Ödendi' ? (
                            <div className="space-y-0.5">
                              <div className="text-xs text-emerald-600 font-semibold flex items-center gap-1">
                                <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
                                Söz Tutuldu ({formatDate(inv.promiseDate)})
                              </div>
                              <div className="text-[11px] text-slate-500 pl-2.5">
                                Tutar: {formatCurrency(inv.promiseAmount || inv.amount)}
                              </div>
                            </div>
                          ) : isPromiseOverdue ? (
                            <div className="space-y-0.5">
                              <div className="text-xs text-rose-700 font-bold flex items-center gap-1 animate-pulse">
                                <span className="inline-block w-2 h-2 rounded-full bg-rose-600"></span>
                                Gecikti! Söz: {formatDate(inv.promiseDate)}
                              </div>
                              <div className="text-xs text-rose-800 font-bold pl-3">
                                Tutar: {formatCurrency(inv.promiseAmount || inv.amount)}
                              </div>
                            </div>
                          ) : (
                            <div className="space-y-0.5">
                              <div className="text-xs text-indigo-700 font-semibold flex items-center gap-1">
                                <span className="inline-block w-1.5 h-1.5 rounded-full bg-indigo-500"></span>
                                Söz Tarihi: {formatDate(inv.promiseDate)}
                              </div>
                              <div className="text-[11px] text-indigo-600 font-semibold pl-2.5">
                                Tutar: {formatCurrency(inv.promiseAmount || inv.amount)}
                              </div>
                            </div>
                          )
                        ) : (
                          <button
                            onClick={() => onEdit(inv)}
                            className="text-[11px] text-indigo-600 hover:text-indigo-800 font-semibold hover:underline cursor-pointer"
                            title="Ödeme sözü eklemek için tıklayın"
                          >
                            + Söz Alındı
                          </button>
                        )}
                      </td>

                      {/* Status/Deadline analysis */}
                      <td className="px-6 py-4.5">
                        <div className="flex items-center gap-2">
                          {inv.status === 'Bekliyor' && dueState === 'overdue' && (
                            <div className="w-2.5 h-2.5 rounded-full bg-rose-500 animate-ping"></div>
                          )}
                          {inv.status === 'Bekliyor' && dueState === 'upcoming' && (
                            <div className="w-2.5 h-2.5 rounded-full bg-amber-400"></div>
                          )}
                          <span className={`text-xs ${remaining.colorClass}`}>
                            {remaining.text}
                          </span>
                        </div>
                      </td>

                      {/* Status Toggle Box */}
                      <td className="px-6 py-4.5 text-center">
                        <div className="inline-flex rounded-xl bg-slate-100 p-1 border border-slate-200">
                          {(['Bekliyor', 'Ödendi'] as InvoiceStatus[]).map((st) => {
                            const isSelected = inv.status === st;
                            let activeBadge = '';
                            if (st === 'Bekliyor') activeBadge = 'bg-amber-500 text-white shadow-xs';
                            if (st === 'Ödendi') activeBadge = 'bg-emerald-600 text-white shadow-xs';

                            return (
                              <button
                                key={st}
                                onClick={() => onStatusChange(inv.id, st)}
                                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all cursor-pointer ${
                                  isSelected ? activeBadge : 'text-slate-500 hover:text-slate-950'
                                }`}
                              >
                                {st}
                              </button>
                            );
                          })}
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="px-6 py-4.5 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          <button
                            onClick={() => onEdit(inv)}
                            className="p-1.5 text-slate-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors cursor-pointer"
                            title="Düzenle"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => onDelete(inv.id)}
                            className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors cursor-pointer"
                            title="Sil"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              ) : (
                <tr>
                  <td colSpan={8} className="px-6 py-12 text-center text-slate-400">
                    <div className="flex flex-col items-center justify-center space-y-2">
                      <div className="p-3 bg-slate-100 rounded-full text-slate-400">
                        <Search className="w-6 h-6" />
                      </div>
                      <p className="text-sm font-semibold text-slate-700">Hiçbir cari kayıt bulunamadı</p>
                      <p className="text-xs text-slate-400 max-w-md">
                        Belirttiğiniz kriterlere veya arama süzgecine uygun veri bulunamadı. Filtreleri temizleyebilir veya yeni kayıt ekleyebilirsiniz.
                      </p>
                      <button
                        onClick={handleResetFilters}
                        className="mt-2 text-xs font-bold text-indigo-600 hover:underline"
                      >
                        Süzgeçleri Temizle
                      </button>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>

          </table>
        </div>

        {/* Footer info bar */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500">
          <div>
            Gösterilen Kayıt Sayısı: <strong>{filteredInvoices.length} / {invoices.length}</strong>
          </div>
          <div className="flex flex-wrap items-center gap-4 mt-2 sm:mt-0 font-medium">
            <span className="flex items-center gap-1 font-bold text-rose-700">
              <span className="w-2.5 h-2.5 rounded-full bg-red-600 inline-block animate-pulse"></span>
              Sözü Geciken (Kırmızı Satır)
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500 inline-block"></span>
              Geciken Cari
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 inline-block"></span>
              Yaklaşan Cari
            </span>
            <span className="flex items-center gap-1">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 inline-block"></span>
              Ödenmiş Cari
            </span>
          </div>
        </div>

      </div>

    </div>
  );
};
