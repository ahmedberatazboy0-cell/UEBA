import React from 'react';
import { DashboardStats } from '../types';
import { Percent, Wallet, AlertCircle, CheckSquare } from 'lucide-react';

interface SummaryChartsProps {
  stats: DashboardStats;
}

export const SummaryCharts: React.FC<SummaryChartsProps> = ({ stats }) => {
  const { totalAmount, paidAmount, pendingAmount, overdueCount, upcomingCount, pendingCount } = stats;

  const collectionRate = totalAmount > 0 ? Math.round((paidAmount / totalAmount) * 100) : 0;
  const pendingRate = totalAmount > 0 ? Math.round((pendingAmount / totalAmount) * 100) : 0;
  const overdueAmount = totalAmount - paidAmount - pendingAmount;
  const overdueRate = totalAmount > 0 ? Math.round((Math.max(0, overdueAmount) / totalAmount) * 100) : 0;

  // Formatting helpers
  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY', maximumFractionDigits: 0 }).format(val);
  };

  // SVG Gauge calculations
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (collectionRate / 100) * circumference;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
      
      {/* 1. Collection Rate Gauge */}
      <div className="bg-white rounded-2xl border border-slate-100 p-6 flex flex-col justify-between shadow-xs">
        <div>
          <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <Percent className="w-4 h-4 text-indigo-600" />
            Vezne Tahsilat Oranı
          </h4>
          <p className="text-xs text-slate-400">Toplam faturaya göre tahsil edilen tutarın oranı</p>
        </div>

        <div className="my-6 flex items-center justify-center relative">
          <svg className="w-36 h-36 transform -rotate-90">
            {/* Background circle */}
            <circle
              cx="72"
              cy="72"
              r={radius}
              className="stroke-slate-100"
              strokeWidth="12"
              fill="transparent"
            />
            {/* Progress circle */}
            <circle
              cx="72"
              cy="72"
              r={radius}
              className="stroke-emerald-500 transition-all duration-1000 ease-out"
              strokeWidth="12"
              fill="transparent"
              strokeDasharray={circumference}
              strokeDashoffset={strokeDashoffset}
              strokeLinecap="round"
            />
          </svg>
          <div className="absolute text-center">
            <span className="text-3xl font-extrabold text-slate-900 tracking-tight">%{collectionRate}</span>
            <span className="text-[10px] text-slate-400 block font-semibold uppercase tracking-wider">Tahsil Edildi</span>
          </div>
        </div>

        <div className="pt-3 border-t border-slate-50 flex justify-between text-xs text-slate-500">
          <div className="flex items-center gap-1">
            <span className="inline-block w-2.5 h-2.5 bg-emerald-500 rounded-full"></span>
            <span>Tahsil Edilen: <strong>{formatCurrency(paidAmount)}</strong></span>
          </div>
          <div>
            <span>Hedef: <strong>{formatCurrency(totalAmount)}</strong></span>
          </div>
        </div>
      </div>

      {/* 2. Portfolio Breakdown */}
      <div className="bg-white rounded-2xl border border-slate-100 p-6 flex flex-col justify-between shadow-xs lg:col-span-2">
        <div>
          <h4 className="text-sm font-bold text-slate-800 flex items-center gap-1.5">
            <Wallet className="w-4 h-4 text-indigo-600" />
            Finansal Portföy ve Risk Analizi
          </h4>
          <p className="text-xs text-slate-400">Tutarlara göre ödeme durumlarının oransal dağılımı</p>
        </div>

        {/* Custom Visual Distribution Bar */}
        <div className="my-5 space-y-4">
          <div className="h-6 w-full bg-slate-100 rounded-xl overflow-hidden flex shadow-2xs">
            {/* Paid block */}
            {collectionRate > 0 && (
              <div 
                style={{ width: `${collectionRate}%` }} 
                className="bg-emerald-500 hover:bg-emerald-600 transition-all duration-500 relative group cursor-help"
                title={`Tahsil Edildi: %${collectionRate}`}
              >
                <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  %{collectionRate}
                </span>
              </div>
            )}
            {/* Pending block */}
            {pendingRate > 0 && (
              <div 
                style={{ width: `${pendingRate}%` }} 
                className="bg-sky-400 hover:bg-sky-500 transition-all duration-500 relative group cursor-help"
                title={`Bekliyor (Gelecek): %${pendingRate}`}
              >
                <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  %{pendingRate}
                </span>
              </div>
            )}
            {/* Overdue block */}
            {overdueRate > 0 && (
              <div 
                style={{ width: `${overdueRate}%` }} 
                className="bg-rose-500 hover:bg-rose-600 transition-all duration-500 relative group cursor-help"
                title={`Vadesi Geçmiş: %${overdueRate}`}
              >
                <span className="absolute inset-0 flex items-center justify-center text-[10px] font-bold text-white opacity-0 group-hover:opacity-100 transition-opacity">
                  %{overdueRate}
                </span>
              </div>
            )}
          </div>

          {/* Breakdown legend with real values */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            
            <div className="p-3 bg-emerald-50/50 border border-emerald-100/50 rounded-xl">
              <span className="text-[10px] text-slate-500 font-bold uppercase block">Tahsil Edilen (Ödendi)</span>
              <span className="text-sm font-extrabold text-emerald-800 font-mono block">{formatCurrency(paidAmount)}</span>
              <span className="text-[10px] text-emerald-600 font-medium">Toplam portföyün %{collectionRate}'i</span>
            </div>

            <div className="p-3 bg-sky-50/50 border border-sky-100/50 rounded-xl">
              <span className="text-[10px] text-slate-500 font-bold uppercase block">Vadesi Gelmemiş (Bekliyor)</span>
              <span className="text-sm font-extrabold text-sky-800 font-mono block">{formatCurrency(pendingAmount)}</span>
              <span className="text-[10px] text-sky-600 font-medium">Toplam portföyün %{pendingRate}'i</span>
            </div>

            <div className="p-3 bg-rose-50/50 border border-rose-100/50 rounded-xl">
              <span className="text-[10px] text-slate-500 font-bold uppercase block">Geciken (Vadesi Geçen)</span>
              <span className="text-sm font-extrabold text-rose-800 font-mono block">{formatCurrency(Math.max(0, overdueAmount))}</span>
              <span className="text-[10px] text-rose-600 font-medium">Toplam portföyün %{overdueRate}'i</span>
            </div>

          </div>
        </div>

        {/* Count indicators at the bottom */}
        <div className="pt-3 border-t border-slate-50 flex flex-wrap justify-between gap-4 text-xs text-slate-500 font-medium">
          <div className="flex items-center gap-1.5">
            <CheckSquare className="w-4 h-4 text-emerald-500" />
            <span>Aktif ödenmiş cari sayısı: <strong className="text-slate-900">{stats.totalAmount - stats.pendingAmount - overdueAmount > 0 ? stats.paidAmount > 0 ? 'Mevcut' : '0' : 'Sistemde Var'}</strong></span>
          </div>
          <div className="flex items-center gap-1.5">
            <AlertCircle className="w-4 h-4 text-rose-500 animate-pulse" />
            <span>Risk altındaki toplam fatura: <strong className="text-rose-600">{overdueCount} Adet</strong></span>
          </div>
          <div className="flex items-center gap-1.5">
            <span className="inline-block w-2 h-2 rounded-full bg-amber-400"></span>
            <span>Yaklaşan takip sayısı: <strong className="text-slate-900">{upcomingCount} Adet</strong></span>
          </div>
        </div>

      </div>

    </div>
  );
};
