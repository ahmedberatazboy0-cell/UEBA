import React, { useState, useEffect } from 'react';
import { Invoice, InvoiceStatus } from '../types';
import { X, Check, Save } from 'lucide-react';
import { CURRENT_DATE_STR } from '../data';

interface InvoiceFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (data: {
    id?: string;
    companyName: string;
    amount: number;
    dueDate: string;
    status: InvoiceStatus;
    notes?: string;
    promiseDate?: string;
    promiseAmount?: number;
    phone?: string;
  }) => void;
  invoiceToEdit?: Invoice | null;
}

export const InvoiceFormModal: React.FC<InvoiceFormModalProps> = ({
  isOpen,
  onClose,
  onSubmit,
  invoiceToEdit
}) => {
  const [companyName, setCompanyName] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState(CURRENT_DATE_STR);
  const [status, setStatus] = useState<InvoiceStatus>('Bekliyor');
  const [notes, setNotes] = useState('');
  const [phone, setPhone] = useState('');
  
  // Payment Promise states
  const [hasPromise, setHasPromise] = useState(false);
  const [promiseDate, setPromiseDate] = useState('');
  const [promiseAmount, setPromiseAmount] = useState('');

  // Validations state
  const [errors, setErrors] = useState<{ [key: string]: string }>({});

  useEffect(() => {
    if (invoiceToEdit) {
      setCompanyName(invoiceToEdit.companyName);
      setAmount(invoiceToEdit.amount.toString());
      setDueDate(invoiceToEdit.dueDate);
      setStatus(invoiceToEdit.status);
      setNotes(invoiceToEdit.notes || '');
      setPhone(invoiceToEdit.phone || '');
      setHasPromise(!!invoiceToEdit.promiseDate);
      setPromiseDate(invoiceToEdit.promiseDate || '');
      setPromiseAmount(invoiceToEdit.promiseAmount ? invoiceToEdit.promiseAmount.toString() : '');
      setErrors({});
    } else {
      setCompanyName('');
      setAmount('');
      setDueDate(CURRENT_DATE_STR);
      setStatus('Bekliyor');
      setNotes('');
      setPhone('');
      setHasPromise(false);
      setPromiseDate('');
      setPromiseAmount('');
      setErrors({});
    }
  }, [invoiceToEdit, isOpen]);

  if (!isOpen) return null;

  const validate = (): boolean => {
    const tempErrors: { [key: string]: string } = {};
    if (!companyName.trim()) {
      tempErrors.companyName = 'Firma adı boş bırakılamaz.';
    } else if (companyName.trim().length < 2) {
      tempErrors.companyName = 'Firma adı en az 2 karakter olmalıdır.';
    }

    const numericAmount = parseFloat(amount);
    if (!amount) {
      tempErrors.amount = 'Tutar boş bırakılamaz.';
    } else if (isNaN(numericAmount) || numericAmount <= 0) {
      tempErrors.amount = 'Lütfen sıfırdan büyük geçerli bir tutar giriniz.';
    }

    if (!dueDate) {
      tempErrors.dueDate = 'Vade tarihi boş bırakılamaz.';
    } else {
      const year = new Date(dueDate).getFullYear();
      if (year < 2000 || year > 2100) {
        tempErrors.dueDate = 'Geçerli bir yıl giriniz (2000-2100).';
      }
    }

    // Validation for promise details if checked
    if (hasPromise) {
      if (!promiseDate) {
        tempErrors.promiseDate = 'Ödeme sözü tarihi boş bırakılamaz.';
      } else {
        const pYear = new Date(promiseDate).getFullYear();
        if (pYear < 2000 || pYear > 2100) {
          tempErrors.promiseDate = 'Geçerli bir söz tarihi giriniz.';
        }
      }
      
      const numPromiseAmount = parseFloat(promiseAmount);
      if (promiseAmount && (isNaN(numPromiseAmount) || numPromiseAmount <= 0)) {
        tempErrors.promiseAmount = 'Geçerli bir söz tutarı giriniz.';
      }
    }

    setErrors(tempErrors);
    return Object.keys(tempErrors).length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    onSubmit({
      id: invoiceToEdit?.id,
      companyName: companyName.trim(),
      amount: parseFloat(amount),
      dueDate,
      status,
      notes: notes.trim() || undefined,
      promiseDate: hasPromise && promiseDate ? promiseDate : undefined,
      promiseAmount: hasPromise && promiseAmount ? parseFloat(promiseAmount) : undefined,
      phone: phone.trim() || undefined
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs">
      <div 
        id="invoice-modal-content"
        className="bg-white rounded-3xl w-full max-w-lg shadow-xl border border-slate-100 overflow-hidden animate-in fade-in zoom-in-95 duration-150"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 bg-slate-50 border-b border-slate-100">
          <div>
            <h3 className="text-lg font-bold text-slate-900">
              {invoiceToEdit ? 'Fatura Kaydı Düzenle' : 'Yeni Fatura / Vade Kaydı'}
            </h3>
            <p className="text-xs text-slate-500">
              {invoiceToEdit ? 'Mevcut kaydı güncelleyin' : 'Takip için yeni bir cari vade ekleyin'}
            </p>
          </div>
          <button 
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {/* Company Name */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700 block">
              Firma Adı <span className="text-rose-500">*</span>
            </label>
            <input
              type="text"
              placeholder="Örn: ABC Teknolojileri Ltd. Şti."
              value={companyName}
              onChange={(e) => setCompanyName(e.target.value)}
              className={`w-full px-4 py-2.5 rounded-xl text-slate-900 bg-white border text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all ${
                errors.companyName ? 'border-rose-400 focus:ring-rose-500' : 'border-slate-200'
              }`}
            />
            {errors.companyName && (
              <p className="text-xs text-rose-500 font-medium">{errors.companyName}</p>
            )}
          </div>

          {/* Phone Number */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700 block">
              Telefon Numarası (WhatsApp İçin)
            </label>
            <input
              type="text"
              placeholder="Örn: 05551234567 veya 5551234567"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl text-slate-900 bg-white border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all"
            />
            <p className="text-[11px] text-slate-400">
              Müşteriye tek tıkla hatırlatma mesajı gönderebilmek için buraya telefon numarası girin.
            </p>
          </div>

          {/* Amount & Due Date row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {/* Amount */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 block">
                Tutar (TRY) <span className="text-rose-500">*</span>
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 text-sm font-semibold">₺</span>
                <input
                  type="number"
                  step="0.01"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className={`w-full pl-8 pr-4 py-2.5 rounded-xl text-slate-900 bg-white border text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all ${
                    errors.amount ? 'border-rose-400 focus:ring-rose-500' : 'border-slate-200'
                  }`}
                />
              </div>
              {errors.amount && (
                <p className="text-xs text-rose-500 font-medium">{errors.amount}</p>
              )}
            </div>

            {/* Due Date */}
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-slate-700 block">
                Vade Tarihi <span className="text-rose-500">*</span>
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className={`w-full px-4 py-2.5 rounded-xl text-slate-900 bg-white border text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all ${
                  errors.dueDate ? 'border-rose-400 focus:ring-rose-500' : 'border-slate-200'
                }`}
              />
              {errors.dueDate && (
                <p className="text-xs text-rose-500 font-medium">{errors.dueDate}</p>
              )}
            </div>
          </div>

          {/* Status Select */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700 block">Ödeme Durumu</label>
            <div className="grid grid-cols-3 gap-2">
              {(['Bekliyor', 'Ödendi', 'İptal Edildi'] as InvoiceStatus[]).map((statusOption) => {
                const isSelected = status === statusOption;
                let activeStyles = '';
                if (statusOption === 'Bekliyor') activeStyles = 'border-amber-400 bg-amber-50 text-amber-700 font-semibold ring-2 ring-amber-400/20';
                if (statusOption === 'Ödendi') activeStyles = 'border-emerald-400 bg-emerald-50 text-emerald-700 font-semibold ring-2 ring-emerald-400/20';
                if (statusOption === 'İptal Edildi') activeStyles = 'border-slate-400 bg-slate-50 text-slate-700 font-semibold ring-2 ring-slate-400/20';

                return (
                  <button
                    key={statusOption}
                    type="button"
                    onClick={() => setStatus(statusOption)}
                    className={`px-3 py-2 rounded-xl text-xs border text-center transition-all cursor-pointer ${
                      isSelected ? activeStyles : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    {statusOption}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Payment Promise (Ödeme Sözü) Section */}
          <div className="bg-indigo-50/50 rounded-2xl border border-indigo-100/60 p-4 space-y-3.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-indigo-900 flex items-center gap-1.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasPromise}
                  onChange={(e) => setHasPromise(e.target.checked)}
                  className="w-4 h-4 rounded-md border-slate-300 text-indigo-600 focus:ring-indigo-500 accent-indigo-600"
                />
                Müşteriden Ödeme Sözü Alındı mı?
              </label>
              <span className="text-[10px] font-bold uppercase text-indigo-600 tracking-wider">Ödeme Sözü Takibi</span>
            </div>

            {hasPromise && (
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-2 animate-in fade-in duration-200">
                {/* Promise Date */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-700 block">
                    Ödeme Sözü Tarihi <span className="text-rose-500">*</span>
                  </label>
                  <input
                    type="date"
                    value={promiseDate}
                    onChange={(e) => setPromiseDate(e.target.value)}
                    className={`w-full px-3.5 py-2 rounded-lg text-slate-900 bg-white border text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500 ${
                      errors.promiseDate ? 'border-rose-400 focus:ring-rose-500' : 'border-slate-200'
                    }`}
                  />
                  {errors.promiseDate && (
                    <p className="text-[10px] text-rose-500 font-medium">{errors.promiseDate}</p>
                  )}
                </div>

                {/* Promise Amount */}
                <div className="space-y-1.5">
                  <label className="text-[11px] font-semibold text-slate-700 block">
                    Söz Verilen Tutar (₺)
                  </label>
                  <input
                    type="number"
                    step="0.01"
                    placeholder="Boş bırakılırsa ana tutar geçerli"
                    value={promiseAmount}
                    onChange={(e) => setPromiseAmount(e.target.value)}
                    className={`w-full px-3.5 py-2 rounded-lg text-slate-900 bg-white border text-xs focus:outline-hidden focus:ring-2 focus:ring-indigo-500 ${
                      errors.promiseAmount ? 'border-rose-400 focus:ring-rose-500' : 'border-slate-200'
                    }`}
                  />
                  {errors.promiseAmount && (
                    <p className="text-[10px] text-rose-500 font-medium">{errors.promiseAmount}</p>
                  )}
                </div>
              </div>
            )}
          </div>

          {/* Notes */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-slate-700 block">Açıklama / Notlar (İsteğe Bağlı)</label>
            <textarea
              rows={2}
              placeholder="Faturaya dair ofis içi ek notlar veya ayrıntılar..."
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              className="w-full px-4 py-2.5 rounded-xl text-slate-900 bg-white border border-slate-200 text-sm focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all resize-none"
            />
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-4 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl border border-slate-200 text-sm font-medium text-slate-600 hover:bg-slate-50 active:bg-slate-100 transition-colors cursor-pointer"
            >
              Vazgeç
            </button>
            <button
              type="submit"
              className="flex-1 py-2.5 rounded-xl bg-slate-900 text-sm font-semibold text-white hover:bg-slate-800 active:bg-slate-950 transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Save className="w-4 h-4" />
              {invoiceToEdit ? 'Değişiklikleri Kaydet' : 'Kaydı Ekle'}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
