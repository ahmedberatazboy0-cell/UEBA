import React, { useState } from 'react';
import { Invoice } from '../types';
import { parseCSV, exportToCSV } from '../data';
import { FileDown, FileUp, Info, Check, AlertCircle, Copy, ClipboardCheck, RefreshCw } from 'lucide-react';

interface CsvToolsProps {
  onImport: (newInvoices: Invoice[]) => void;
  onResetToDefaults: () => void;
  currentInvoices: Invoice[];
}

export const CsvTools: React.FC<CsvToolsProps> = ({
  onImport,
  onResetToDefaults,
  currentInvoices
}) => {
  const [csvText, setCsvText] = useState('');
  const [copied, setCopied] = useState(false);
  const [importMessage, setImportMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [isPanelOpen, setIsPanelOpen] = useState(false);

  const handleImportSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setImportMessage(null);

    if (!csvText.trim()) {
      setImportMessage({ type: 'error', text: 'Lütfen içe aktarılacak CSV formatında metin girin.' });
      return;
    }

    try {
      const parsed = parseCSV(csvText);
      if (parsed.length === 0) {
        setImportMessage({ 
          type: 'error', 
          text: 'Geçerli bir veri bulunamadı. Lütfen "Firma Adi, Tutar, Vade Tarihi, Durum" yapısına uygun olduğundan emin olun.' 
        });
        return;
      }

      onImport(parsed);
      setImportMessage({ 
        type: 'success', 
        text: `Başarıyla ${parsed.length} adet yeni cari kayıt sisteme eklendi!` 
      });
      setCsvText('');
    } catch (err) {
      setImportMessage({ type: 'error', text: 'CSV ayrıştırılırken beklenmeyen bir hata oluştu.' });
    }
  };

  const handleCopyCurrentAsCSV = () => {
    const csvContent = exportToCSV(currentInvoices);
    navigator.clipboard.writeText(csvContent);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadCSV = () => {
    const csvContent = exportToCSV(currentInvoices);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `muhasebe_takip_verisi_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-100 shadow-xs overflow-hidden">
      {/* Header Bar */}
      <button
        id="csv-tools-toggle"
        onClick={() => setIsPanelOpen(!isPanelOpen)}
        className="w-full flex items-center justify-between px-6 py-4 hover:bg-slate-50/50 transition-colors text-left cursor-pointer"
      >
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-lg bg-indigo-50 border border-indigo-100 text-indigo-600">
            <FileUp className="w-4 h-4" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-slate-800">CSV Veri Yönetimi</h4>
            <p className="text-xs text-slate-400">CSV formatında toplu veri yükleme ve yedekleme işlemleri</p>
          </div>
        </div>
        <span className="text-xs font-semibold text-indigo-600 bg-indigo-50/80 px-3 py-1 rounded-full hover:bg-indigo-100 transition-colors">
          {isPanelOpen ? 'Kapat' : 'Göster / Düzenle'}
        </span>
      </button>

      {/* Expanded Panel */}
      {isPanelOpen && (
        <div className="px-6 pb-6 pt-2 border-t border-slate-50 space-y-6 animate-in slide-in-from-top-1 duration-200">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Import Block */}
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 text-slate-700">
                <FileUp className="w-4 h-4 text-slate-500" />
                <span className="text-xs font-bold uppercase tracking-wider">Toplu Veri Ekle (CSV İçe Aktar)</span>
              </div>
              
              <div className="bg-slate-50 border border-slate-200 rounded-xl p-3 text-[11px] text-slate-600 space-y-1.5">
                <div className="flex gap-1 items-start text-slate-800 font-medium">
                  <Info className="w-3.5 h-3.5 text-indigo-500 shrink-0 mt-0.5" />
                  <span>Kabul edilen satır yapısı (Başlıksız veya başlıklı girebilirsiniz):</span>
                </div>
                <code className="block bg-slate-900 text-slate-200 p-2 rounded-lg font-mono leading-relaxed">
                  Firma Adi, Tutar, Vade Tarihi, Durum<br/>
                  ABC Limited, 14500.00, 2026-07-30, Bekliyor<br/>
                  XYZ Danışmanlık, 8250.50, 2026-07-15, Ödendi
                </code>
              </div>

              <form onSubmit={handleImportSubmit} className="space-y-2">
                <textarea
                  rows={4}
                  placeholder="Yukarıdaki örnek formatta verilerinizi buraya yapıştırın..."
                  value={csvText}
                  onChange={(e) => setCsvText(e.target.value)}
                  className="w-full p-3 bg-white border border-slate-200 rounded-xl text-xs font-mono text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
                />
                
                <div className="flex items-center justify-between gap-2">
                  <button
                    type="submit"
                    className="px-4 py-2 bg-slate-950 hover:bg-slate-850 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <Check className="w-3.5 h-3.5" />
                    Yapıştırılan Verileri Ekle
                  </button>
                  <button
                    type="button"
                    onClick={onResetToDefaults}
                    className="px-3 py-2 border border-rose-200 hover:bg-rose-50 text-rose-700 rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                    title="Mevcut tüm verileri temizler."
                  >
                    <RefreshCw className="w-3 h-3" />
                    Tüm Verileri Temizle
                  </button>
                </div>
              </form>

              {importMessage && (
                <div className={`p-3 rounded-lg flex items-start gap-2 text-xs font-medium ${
                  importMessage.type === 'success' ? 'bg-emerald-50 text-emerald-800 border border-emerald-100' : 'bg-rose-50 text-rose-800 border border-rose-100'
                }`}>
                  {importMessage.type === 'success' ? (
                    <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                  ) : (
                    <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
                  )}
                  <span>{importMessage.text}</span>
                </div>
              )}
            </div>

            {/* Export Block */}
            <div className="space-y-4">
              <div className="flex items-center gap-1.5 text-slate-700">
                <FileDown className="w-4 h-4 text-slate-500" />
                <span className="text-xs font-bold uppercase tracking-wider">Veriyi Dışa Aktar (Yedekle)</span>
              </div>
              <p className="text-xs text-slate-500 leading-relaxed">
                Şu anda sistemde bulunan tüm cari takipleri faturasıyla, tutarıyla ve ödeme durumuyla birlikte bilgisayarınıza indirebilir veya panoya kopyalayabilirsiniz. Excel veya diğer muhasebe programları bu veriyi okuyabilir.
              </p>

              <div className="bg-slate-50 border border-slate-100 rounded-xl p-4 space-y-3">
                <div className="text-xs text-slate-600 flex justify-between items-center">
                  <span>Aktarılmaya Hazır Kayıt:</span>
                  <span className="font-bold text-slate-950 font-mono text-sm">{currentInvoices.length} Cari</span>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <button
                    onClick={handleCopyCurrentAsCSV}
                    className="py-2.5 px-3 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    {copied ? <ClipboardCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5 text-slate-500" />}
                    {copied ? 'Kopyalandı' : 'Panoya Kopyala'}
                  </button>
                  <button
                    onClick={handleDownloadCSV}
                    className="py-2.5 px-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                  >
                    <FileDown className="w-3.5 h-3.5" />
                    CSV İndir
                  </button>
                </div>
              </div>

              <div className="p-3 bg-indigo-50/50 rounded-xl text-[11px] text-indigo-800 border border-indigo-100/50">
                <span className="font-bold block mb-0.5">Bilgi:</span>
                Kaydedilen tüm verileriniz tarayıcınızın yerel depolama alanında (localStorage) güvenli bir şekilde saklanır. Ofis dışı başka bir bilgisayarda da verilerinizi görüntülemek için buradan CSV indirip diğer bilgisayardan yükleyebilirsiniz.
              </div>
            </div>

          </div>

        </div>
      )}
    </div>
  );
};
