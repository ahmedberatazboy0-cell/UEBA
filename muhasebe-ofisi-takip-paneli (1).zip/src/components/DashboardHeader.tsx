import React, { useState, useEffect } from 'react';
import { DashboardStats } from '../types';
import { TrendingUp, AlertTriangle, Clock, CheckCircle2, CircleDollarSign, CalendarDays } from 'lucide-react';
import { CURRENT_DATE_STR, safeParseDate } from '../data';

interface DashboardHeaderProps {
  stats: DashboardStats;
  onQuickFilter: (type: 'all' | 'overdue' | 'upcoming' | 'pending' | 'paid') => void;
  activeQuickFilter: string;
}

export const DashboardHeader: React.FC<DashboardHeaderProps> = ({ 
  stats, 
  onQuickFilter,
  activeQuickFilter 
}) => {
  const [liveTime, setLiveTime] = useState<string>('');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setLiveTime(now.toLocaleTimeString('tr-TR', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit'
      }));
    };
    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, []);

  const formatCurrency = (val: number) => {
    return new Intl.NumberFormat('tr-TR', { style: 'currency', currency: 'TRY' }).format(val);
  };

  const statItems = [
    {
      id: 'all',
      title: 'Toplam Alacak Portföyü',
      value: formatCurrency(stats.totalAmount),
      subtitle: `${stats.pendingCount + stats.overdueCount + stats.upcomingCount} aktif fatura`,
      icon: <CircleDollarSign className="w-5 h-5 text-indigo-600" />,
      bg: 'bg-white border-slate-100 hover:border-indigo-200',
      activeBg: 'ring-2 ring-indigo-500 border-indigo-500 bg-indigo-50/20',
      textColor: 'text-indigo-900',
      badgeColor: 'bg-indigo-50 text-indigo-700'
    },
    {
      id: 'overdue',
      title: 'Vadesi Geçenler',
      value: formatCurrency(stats.totalAmount - stats.paidAmount - stats.pendingAmount), // wait, let's keep it clean
      count: stats.overdueCount,
      subtitle: 'Ödemesi gecikmiş firmalar',
      icon: <AlertTriangle className="w-5 h-5 text-rose-600 animate-bounce" />,
      bg: stats.overdueCount > 0 ? 'bg-rose-50/50 border-rose-200 hover:bg-rose-50' : 'bg-white border-slate-100',
      activeBg: 'ring-2 ring-rose-500 border-rose-500 bg-rose-50',
      textColor: 'text-rose-900',
      badgeColor: 'bg-rose-100 text-rose-800'
    },
    {
      id: 'upcoming',
      title: 'Vadesi Yaklaşanlar',
      count: stats.upcomingCount,
      subtitle: 'Önümüzdeki 7 gün içinde',
      icon: <Clock className="w-5 h-5 text-amber-500 animate-pulse" />,
      bg: stats.upcomingCount > 0 ? 'bg-amber-50/50 border-amber-200 hover:bg-amber-50' : 'bg-white border-slate-100',
      activeBg: 'ring-2 ring-amber-500 border-amber-500 bg-amber-50',
      textColor: 'text-amber-900',
      badgeColor: 'bg-amber-100 text-amber-800'
    },
    {
      id: 'pending',
      title: 'Bekleyen Toplam',
      value: formatCurrency(stats.pendingAmount),
      subtitle: 'Gelecek vadeli ödemeler',
      icon: <TrendingUp className="w-5 h-5 text-sky-600" />,
      bg: 'bg-white border-slate-100 hover:border-sky-200',
      activeBg: 'ring-2 ring-sky-500 border-sky-500 bg-sky-50/20',
      textColor: 'text-sky-900',
      badgeColor: 'bg-sky-50 text-sky-700'
    },
    {
      id: 'paid',
      title: 'Tahsil Edilen',
      value: formatCurrency(stats.paidAmount),
      subtitle: 'Başarıyla ödenmiş olanlar',
      icon: <CheckCircle2 className="w-5 h-5 text-emerald-600" />,
      bg: 'bg-white border-slate-100 hover:border-emerald-200',
      activeBg: 'ring-2 ring-emerald-500 border-emerald-500 bg-emerald-50/20',
      textColor: 'text-emerald-900',
      badgeColor: 'bg-emerald-50 text-emerald-700'
    }
  ];

  // Helper to format date nicely
  const formatDateNice = (dateStr: string) => {
    return safeParseDate(dateStr).toLocaleDateString('tr-TR', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      {/* Upper Status Line */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between bg-slate-900 text-white rounded-2xl p-5 shadow-sm border border-slate-800 gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-indigo-400 font-semibold tracking-wider text-xs uppercase">
            <span className="inline-flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse"></span>
            HOŞ GELDİNİZ, EMRAH AZBOY
          </div>
          <h1 className="text-2xl font-bold tracking-tight text-white">Muhasebe Cari & Vade Takip Paneli</h1>
          <p className="text-slate-400 text-sm">
            Kendi verilerinizi girip güvenle takip edebileceğiniz hatasız, modern çalışma ekranı.
          </p>
        </div>
        
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
          {/* Sistem Çalışma Tarihi */}
          <div className="flex items-center gap-3 bg-slate-850 px-4 py-2 rounded-xl border border-slate-750 text-slate-300">
            <CalendarDays className="w-4 h-4 text-indigo-400 shrink-0" />
            <div className="text-sm">
              <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Çalışma Tarihi</span>
              <span className="font-mono font-semibold text-white whitespace-nowrap">{formatDateNice(CURRENT_DATE_STR)}</span>
            </div>
          </div>

          {/* Canlı Sistem Saati */}
          <div className="flex items-center gap-3 bg-slate-850 px-4 py-2 rounded-xl border border-slate-750 text-slate-300">
            <Clock className="w-4 h-4 text-emerald-400 shrink-0 animate-pulse" />
            <div className="text-sm">
              <span className="text-slate-500 text-[10px] uppercase font-bold tracking-wider block">Canlı Sistem Saati</span>
              <span className="font-mono font-bold text-emerald-400 whitespace-nowrap">{liveTime || 'Yükleniyor...'}</span>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4">
        {statItems.map((item) => {
          const isActive = activeQuickFilter === item.id;
          return (
            <button
              key={item.id}
              id={`stat-card-${item.id}`}
              onClick={() => onQuickFilter(item.id as any)}
              className={`text-left p-5 rounded-2xl border transition-all duration-300 shadow-xs cursor-pointer ${
                isActive ? item.activeBg : item.bg
              }`}
            >
              <div className="flex items-start justify-between">
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 shadow-2xs">
                  {item.icon}
                </div>
                {item.count !== undefined && (
                  <span className={`text-xs px-2.5 py-1 rounded-full font-bold ${item.badgeColor}`}>
                    {item.count} Kayıt
                  </span>
                )}
              </div>
              <div className="mt-4 space-y-1">
                <span className="text-slate-500 text-xs block font-medium uppercase tracking-wider">
                  {item.title}
                </span>
                <span className={`text-xl font-bold tracking-tight block ${item.textColor}`}>
                  {item.value || `${item.count} Adet`}
                </span>
                <span className="text-slate-400 text-xs block">
                  {item.subtitle}
                </span>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
