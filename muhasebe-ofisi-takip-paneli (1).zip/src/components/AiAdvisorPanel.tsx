import React, { useState, useRef, useEffect } from 'react';
import { Invoice } from '../types';
import { Bot, Sparkles, X, Send, RefreshCw, AlertCircle, MessageSquare, ArrowRight } from 'lucide-react';

interface Message {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: Date;
}

interface AiAdvisorPanelProps {
  isOpen: boolean;
  onClose: () => void;
  invoices: Invoice[];
}

export function AiAdvisorPanel({ isOpen, onClose, invoices }: AiAdvisorPanelProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'ai',
      text: `Merhaba! Ben sizin **AI Finansal Danışmanınızım**. 

Sistemdeki güncel cari hesap, ödeme sözleri, vade tarihleri ve telefon numarası verilerini analiz ederek size şu konularda destek olabilirim:
- Ödemesi acil olan kritik firmaların tespiti,
- Nakit akışı ve risk durumunun analizi,
- Geciken alacaklar için WhatsApp üzerinden gönderebileceğiniz **kibar uyarı mesajları** hazırlama,
- Özel finansal sorularınızı yanıtlama.

Analize başlamak için aşağıdaki hazır komutlardan birini seçebilir veya alt taraftaki sohbet kutusundan bana dilediğiniz soruyu sorabilirsiniz!`,
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  const quickPrompts = [
    {
      label: '🚨 En Acil 5 Firma',
      prompt: 'Bu ay en acil aranması gereken 5 firma kim?'
    },
    {
      label: '📊 Durum Özetle & Riskler',
      prompt: 'Genel tahsilat durumumuzu ve riskli müşterileri özetle.'
    },
    {
      label: '✉️ Kibar WhatsApp Mesajı Yaz',
      prompt: 'Geciken alacaklar için müşteriye gönderebileceğim kibar bir uyarı metni yaz.'
    }
  ];

  const handleSend = async (textToSend: string) => {
    if (!textToSend.trim() || isLoading) return;

    const userMsgId = Date.now().toString();
    const newUserMessage: Message = {
      id: userMsgId,
      sender: 'user',
      text: textToSend,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, newUserMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          prompt: textToSend,
          invoices: invoices
        })
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Yapay zeka sunucusu yanıt vermedi.');
      }

      const data = await response.json();
      
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: data.text || 'Üzgünüm, boş bir yanıt aldım.',
        timestamp: new Date()
      }]);
    } catch (err: any) {
      console.error(err);
      setMessages(prev => [...prev, {
        id: (Date.now() + 1).toString(),
        sender: 'ai',
        text: `⚠️ **Bağlantı Hatası:** Yapay zeka ile iletişim kurulurken bir sorun oluştu.\n\n*Detay: ${err.message || 'Lütfen internet bağlantınızı veya API anahtarınızı kontrol edin.'}*`,
        timestamp: new Date()
      }]);
    } finally {
      setIsLoading(false);
    }
  };

  const clearChat = () => {
    if (window.confirm('Sohbet geçmişini sıfırlamak istediğinize emin misiniz?')) {
      setMessages([
        {
          id: 'welcome',
          sender: 'ai',
          text: 'Sohbet geçmişi temizlendi. Dilediğiniz zaman analiz yapmaya veya soru sormaya devam edebilirsiniz!',
          timestamp: new Date()
        }
      ]);
    }
  };

  // Safe markdown render helper (simple bold and list conversion)
  const renderMessageText = (text: string) => {
    return text.split('\n').map((line, i) => {
      let renderedLine = line;
      
      // Simple Bold formatting **text** -> <strong>text</strong>
      const boldRegex = /\*\*(.*?)\*\*/g;
      const parts = [];
      let lastIndex = 0;
      let match;
      
      while ((match = boldRegex.exec(line)) !== null) {
        if (match.index > lastIndex) {
          parts.push(renderedLine.substring(lastIndex, match.index));
        }
        parts.push(<strong key={match.index} className="font-bold text-slate-900">{match[1]}</strong>);
        lastIndex = boldRegex.lastIndex;
      }
      if (lastIndex < line.length) {
        parts.push(renderedLine.substring(lastIndex));
      }

      const content = parts.length > 0 ? parts : line;

      // Unordered lists starting with "- " or "* "
      if (line.trim().startsWith('- ') || line.trim().startsWith('* ')) {
        const listText = line.trim().substring(2);
        return (
          <li key={i} className="list-disc ml-4 my-1 pl-1 text-slate-750">
            {listText.includes('**') ? content : listText}
          </li>
        );
      }

      // Check if numbered list
      const numListMatch = line.trim().match(/^(\d+)\.\s(.*)/);
      if (numListMatch) {
        return (
          <li key={i} className="list-decimal ml-4 my-1 pl-1 text-slate-750">
            {numListMatch[2].includes('**') ? content : numListMatch[2]}
          </li>
        );
      }

      // Blockquotes
      if (line.trim().startsWith('> ')) {
        return (
          <blockquote key={i} className="border-l-4 border-indigo-200 pl-3 italic my-1.5 text-slate-500 text-xs">
            {line.trim().substring(2)}
          </blockquote>
        );
      }

      // Subheadings with ### or ##
      if (line.trim().startsWith('###')) {
        return <h4 key={i} className="font-bold text-xs text-indigo-900 mt-3 mb-1">{line.trim().replace('###', '').trim()}</h4>;
      }
      if (line.trim().startsWith('##')) {
        return <h3 key={i} className="font-bold text-sm text-slate-900 mt-4 mb-1.5 border-b border-slate-100 pb-1">{line.trim().replace('##', '').trim()}</h3>;
      }

      return (
        <p key={i} className={line.trim() === '' ? 'h-2' : 'my-1 text-slate-750'}>
          {content}
        </p>
      );
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex justify-end overflow-hidden">
      {/* Backdrop overlay */}
      <div 
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-xs transition-opacity"
        onClick={onClose}
      ></div>

      {/* Drawer content panel */}
      <div className="relative w-full max-w-lg bg-white h-full shadow-2xl flex flex-col z-10 border-l border-slate-200 animate-in slide-in-from-right duration-300">
        
        {/* Drawer Header */}
        <div className="px-6 py-5 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-xl bg-indigo-600 flex items-center justify-center text-white shadow-xs shadow-indigo-200">
              <Bot className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <h2 className="text-sm font-bold text-slate-900">AI Finansal Danışman</h2>
                <span className="flex h-2 w-2 rounded-full bg-emerald-500 animate-pulse" title="Çevrimiçi"></span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Gemini 3.5 Flash ile Cari & Tahsilat Analizi</p>
            </div>
          </div>
          
          <div className="flex items-center gap-1.5">
            <button
              onClick={clearChat}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Sohbeti Sıfırla"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors cursor-pointer"
              title="Kapat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Current Context Status Badge */}
        <div className="bg-indigo-50/60 px-6 py-2 border-b border-indigo-100 text-[11px] text-indigo-700 flex items-center justify-between font-medium">
          <span>Veri Havuzu: <strong>{invoices.length} Cari Kayıt</strong> analiz edilmeye hazır</span>
          <span className="bg-indigo-100 px-2 py-0.5 rounded-full text-[10px]">Canlı Veri Bağlantısı</span>
        </div>

        {/* Messages / Discussion Body */}
        <div className="flex-1 overflow-y-auto px-6 py-4 space-y-4 bg-slate-50/30">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex ${msg.sender === 'user' ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-150`}
            >
              <div
                className={`max-w-[88%] rounded-2xl p-4 shadow-2xs ${
                  msg.sender === 'user'
                    ? 'bg-indigo-600 text-white rounded-tr-none text-xs font-medium'
                    : 'bg-white border border-slate-200/80 text-slate-800 rounded-tl-none text-xs leading-relaxed space-y-1'
                }`}
              >
                {msg.sender === 'user' ? (
                  <p className="whitespace-pre-wrap">{msg.text}</p>
                ) : (
                  <div className="space-y-1.5">
                    {renderMessageText(msg.text)}
                  </div>
                )}
                
                <div className={`text-[9px] mt-2 block text-right ${msg.sender === 'user' ? 'text-indigo-200' : 'text-slate-400'}`}>
                  {msg.timestamp.toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' })}
                </div>
              </div>
            </div>
          ))}

          {/* Thinking / Loading indicator */}
          {isLoading && (
            <div className="flex justify-start animate-pulse">
              <div className="bg-white border border-slate-200 rounded-2xl rounded-tl-none p-4 max-w-[80%] flex items-center gap-3">
                <div className="flex space-x-1.5">
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 bg-indigo-500 rounded-full animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
                <span className="text-[11px] text-slate-400 font-medium">AI Danışman analiz ediyor...</span>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* Footer Area with Quick Prompts & Inputs */}
        <div className="p-4 border-t border-slate-100 bg-white space-y-3.5">
          
          {/* Quick Prompts Carousel/Buttons */}
          <div className="space-y-1.5">
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider px-1">Örnek Analiz Komutları</p>
            <div className="flex flex-col gap-1.5">
              {quickPrompts.map((qp, index) => (
                <button
                  key={index}
                  onClick={() => handleSend(qp.prompt)}
                  disabled={isLoading}
                  className="w-full text-left px-3 py-2 bg-slate-50 hover:bg-slate-100 active:bg-slate-200 border border-slate-100 rounded-xl text-[11px] font-semibold text-slate-700 transition-all flex items-center justify-between group disabled:opacity-50 disabled:pointer-events-none cursor-pointer"
                >
                  <span>{qp.label}</span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400 group-hover:text-indigo-500 group-hover:translate-x-0.5 transition-all" />
                </button>
              ))}
            </div>
          </div>

          {/* Form chat input block */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(input);
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={isLoading}
              placeholder="AI Danışman'a soru sorun... (Örn: Alacaklarımı nasıl artırırım?)"
              className="flex-1 px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-800 text-xs font-medium focus:outline-hidden focus:bg-white focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 transition-all disabled:opacity-60"
            />
            <button
              type="submit"
              disabled={!input.trim() || isLoading}
              className="p-2.5 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white rounded-xl shadow-xs disabled:opacity-40 transition-all cursor-pointer shrink-0"
            >
              <Send className="w-4 h-4" />
            </button>
          </form>

          <p className="text-[10px] text-slate-400 text-center">
            Bu asistan yerel verilerinizi analiz eder ve gizlilik çerçevesinde korur.
          </p>
        </div>

      </div>
    </div>
  );
}
