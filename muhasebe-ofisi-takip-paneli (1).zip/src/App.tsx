import { useState, useEffect, useMemo } from 'react';
import { Invoice, DashboardStats, InvoiceStatus } from './types';
import { INITIAL_INVOICES, CURRENT_DATE_STR, getDueStatus } from './data';
import { DashboardHeader } from './components/DashboardHeader';
import { SummaryCharts } from './components/SummaryCharts';
import { InvoiceTable } from './components/InvoiceTable';
import { InvoiceFormModal } from './components/InvoiceFormModal';
import { CsvTools } from './components/CsvTools';
import { AiAdvisorPanel } from './components/AiAdvisorPanel';
import { PlusCircle, RefreshCw, Layers, CheckCircle2, AlertTriangle, HelpCircle, Sparkles, Bot } from 'lucide-react';

const LOCAL_STORAGE_KEY = 'muhasebe_ofis_faturalar_emrah_azboy_v1';

export default function App() {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [invoiceToEdit, setInvoiceToEdit] = useState<Invoice | null>(null);
  const [activeQuickFilter, setActiveQuickFilter] = useState<string>('all');
  const [isAiPanelOpen, setIsAiPanelOpen] = useState(false);
  
  // Custom alerts/toasts state
  const [notification, setNotification] = useState<{ type: 'success' | 'error' | 'info'; text: string } | null>(null);

  // Custom confirmation dialog state
  const [confirmState, setConfirmState] = useState<{
    isOpen: boolean;
    title: string;
    message: string;
    confirmText?: string;
    cancelText?: string;
    onConfirm: () => void;
  } | null>(null);

  // Load from local storage or start empty for Emrah Azboy
  useEffect(() => {
    const stored = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (stored) {
      try {
        setInvoices(JSON.parse(stored));
      } catch (err) {
        setInvoices([]);
      }
    } else {
      setInvoices([]);
      showNotification('info', 'Hoş geldiniz Emrah Bey! Kendi cari verilerinizi girmek için ekranınız hazırlandı.');
    }
  }, []);

  // Save to local storage whenever invoices change
  const saveInvoices = (newInvoices: Invoice[]) => {
    setInvoices(newInvoices);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(newInvoices));
  };

  // Trigger temporary notification toast
  const showNotification = (type: 'success' | 'error' | 'info', text: string) => {
    setNotification({ type, text });
    setTimeout(() => {
      setNotification(null);
    }, 4000);
  };

  // Compute stats in real-time
  const stats: DashboardStats = useMemo(() => {
    let totalAmount = 0;
    let paidAmount = 0;
    let pendingAmount = 0;
    let overdueCount = 0;
    let upcomingCount = 0;
    let pendingCount = 0;

    invoices.forEach((inv) => {
      if (inv.status === 'İptal Edildi') return; // Skip cancelled ones for core stats

      totalAmount += inv.amount;

      if (inv.status === 'Ödendi') {
        paidAmount += inv.amount;
      } else if (inv.status === 'Bekliyor') {
        const dueState = getDueStatus(inv.dueDate, inv.status);
        if (dueState === 'overdue') {
          overdueCount++;
        } else if (dueState === 'upcoming') {
          upcomingCount++;
          pendingAmount += inv.amount;
        } else {
          pendingCount++;
          pendingAmount += inv.amount;
        }
      }
    });

    return {
      totalAmount,
      paidAmount,
      pendingAmount,
      overdueCount,
      upcomingCount,
      pendingCount
    };
  }, [invoices]);

  // Actions
  const handleAddOrEditInvoice = (data: {
    id?: string;
    companyName: string;
    amount: number;
    dueDate: string;
    status: InvoiceStatus;
    notes?: string;
    promiseDate?: string;
    promiseAmount?: number;
    phone?: string;
  }) => {
    if (data.id) {
      // Edit
      const updated = invoices.map(inv => {
        if (inv.id === data.id) {
          return {
            ...inv,
            companyName: data.companyName,
            amount: data.amount,
            dueDate: data.dueDate,
            status: data.status,
            notes: data.notes,
            promiseDate: data.promiseDate,
            promiseAmount: data.promiseAmount,
            phone: data.phone
          };
        }
        return inv;
      });
      saveInvoices(updated);
      showNotification('success', `${data.companyName} kaydı başarıyla güncellendi.`);
    } else {
      // Add new
      const newInvoice: Invoice = {
        id: `invoice-${Date.now()}`,
        companyName: data.companyName,
        amount: data.amount,
        dueDate: data.dueDate,
        status: data.status,
        notes: data.notes,
        createdAt: CURRENT_DATE_STR,
        promiseDate: data.promiseDate,
        promiseAmount: data.promiseAmount,
        phone: data.phone
      };
      saveInvoices([newInvoice, ...invoices]);
      showNotification('success', `${data.companyName} için yeni cari vade kaydı oluşturuldu.`);
    }
    setInvoiceToEdit(null);
  };

  const handleDeleteInvoice = (id: string) => {
    const target = invoices.find(inv => inv.id === id);
    if (!target) return;

    setConfirmState({
      isOpen: true,
      title: 'Cari Kaydı Sil',
      message: `"${target.companyName}" firmasına ait cari vade kaydını silmek istediğinize emin misiniz? Bu işlem geri alınamaz.`,
      confirmText: 'Evet, Sil',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        const remaining = invoices.filter(inv => inv.id !== id);
        saveInvoices(remaining);
        showNotification('info', `${target.companyName} cari kaydı silindi.`);
        setConfirmState(null);
      }
    });
  };

  const handleStatusChange = (id: string, newStatus: InvoiceStatus) => {
    const updated = invoices.map(inv => {
      if (inv.id === id) {
        return { ...inv, status: newStatus };
      }
      return inv;
    });
    saveInvoices(updated);
    const target = invoices.find(inv => inv.id === id);
    showNotification('success', `${target?.companyName || 'Cari'} durumu "${newStatus}" olarak güncellendi.`);
  };

  const handleImportCSV = (newInvoices: Invoice[]) => {
    saveInvoices([...newInvoices, ...invoices]);
    showNotification('success', `${newInvoices.length} cari kayıt CSV dosyasından toplu olarak eklendi.`);
  };

  const handleResetToDefaults = () => {
    setConfirmState({
      isOpen: true,
      title: 'Tüm Verileri Temizle',
      message: 'Sistemdeki tüm mevcut cari kayıtları, ödeme sözlerini ve telefon verilerini tamamen temizlemek istediğinize emin misiniz? Bu işlem geri alınamaz.',
      confirmText: 'Evet, Tümünü Temizle',
      cancelText: 'Vazgeç',
      onConfirm: () => {
        saveInvoices([]);
        showNotification('info', 'Tüm cari kayıtlar ve fatura verileri başarıyla temizlendi.');
        setConfirmState(null);
      }
    });
  };

  const handleQuickFilterClick = (type: string) => {
    setActiveQuickFilter(type);
  };

  return (
    <div className="min-h-screen bg-slate-50 text-slate-800 font-sans antialiased pb-20">
      
      {/* Toast Notification */}
      {notification && (
        <div className="fixed top-5 right-5 z-50 animate-in fade-in slide-in-from-top-3 duration-200">
          <div className={`p-4 rounded-2xl shadow-xl border flex items-center gap-3 max-w-sm ${
            notification.type === 'success' 
              ? 'bg-emerald-600 text-white border-emerald-500' 
              : notification.type === 'error'
              ? 'bg-rose-600 text-white border-rose-500'
              : 'bg-indigo-600 text-white border-indigo-500'
          }`}>
            {notification.type === 'success' && <CheckCircle2 className="w-5 h-5 shrink-0" />}
            {notification.type === 'error' && <AlertTriangle className="w-5 h-5 shrink-0" />}
            {notification.type === 'info' && <HelpCircle className="w-5 h-5 shrink-0" />}
            <span className="text-xs font-semibold leading-relaxed">{notification.text}</span>
          </div>
        </div>
      )}

      {/* Main Container */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-8 space-y-6">
        
        {/* Header Block */}
        <DashboardHeader 
          stats={stats} 
          onQuickFilter={handleQuickFilterClick} 
          activeQuickFilter={activeQuickFilter}
        />

        {/* Dynamic Interactive Charts */}
        <SummaryCharts stats={stats} />

        {/* Toolbar Line */}
        <div className="flex items-center justify-between bg-white rounded-2xl border border-slate-100 px-6 py-4 shadow-2xs">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-indigo-600" />
            <h3 className="text-sm font-bold text-slate-800">Cari İşlemler & Vadeli Faturalar</h3>
            {activeQuickFilter !== 'all' && (
              <span className="text-[10px] bg-indigo-50 text-indigo-700 px-2.5 py-0.5 rounded-full font-bold ml-2">
                Kart Filtresi Aktif
              </span>
            )}
          </div>
          
          <div className="flex items-center gap-3">
            <button
              onClick={() => setIsAiPanelOpen(true)}
              className="px-4 py-2.5 bg-indigo-50 hover:bg-indigo-100 active:bg-indigo-200 text-indigo-700 text-xs font-bold rounded-xl border border-indigo-100 transition-all flex items-center gap-2 cursor-pointer relative group"
            >
              <Sparkles className="w-4 h-4 text-indigo-600" />
              AI Finansal Danışman
              <span className="absolute -top-1 -right-1 flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-indigo-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-indigo-500"></span>
              </span>
            </button>

            <button
              onClick={() => {
                setInvoiceToEdit(null);
                setIsFormModalOpen(true);
              }}
              className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold rounded-xl shadow-xs hover:shadow-md transition-all flex items-center gap-2 cursor-pointer"
            >
              <PlusCircle className="w-4 h-4" />
              Yeni Cari Kaydı Ekle
            </button>
          </div>
        </div>

        {/* Invoices List / Table */}
        <InvoiceTable 
          invoices={invoices}
          onEdit={(inv) => {
            setInvoiceToEdit(inv);
            setIsFormModalOpen(true);
          }}
          onDelete={handleDeleteInvoice}
          onStatusChange={handleStatusChange}
          activeQuickFilter={activeQuickFilter}
        />

        {/* Bulk Data & Backup management */}
        <CsvTools 
          onImport={handleImportCSV} 
          onResetToDefaults={handleResetToDefaults} 
          currentInvoices={invoices}
        />

        {/* Humble system signature / info */}
        <footer className="text-center text-slate-400 text-xs py-4">
          Muhasebe Ofisi Cari Vade Takip Sistemi &bull; Tarayıcı Tabanlı Güvenli Yerel Depolama (Offline-First)
        </footer>

      </main>

      {/* Entry Form Modal */}
      <InvoiceFormModal 
        isOpen={isFormModalOpen}
        onClose={() => {
          setIsFormModalOpen(false);
          setInvoiceToEdit(null);
        }}
        onSubmit={handleAddOrEditInvoice}
        invoiceToEdit={invoiceToEdit}
      />

      {/* Custom Confirmation Modal */}
      {confirmState && confirmState.isOpen && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          {/* Backdrop overlay */}
          <div 
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs transition-opacity duration-300"
            onClick={() => setConfirmState(null)}
          ></div>

          {/* Dialog frame */}
          <div className="flex min-h-screen items-center justify-center p-4 text-center">
            <div className="relative transform overflow-hidden rounded-2xl bg-white text-left shadow-2xl transition-all sm:my-8 sm:w-full sm:max-w-md border border-slate-200 animate-in fade-in zoom-in-95 duration-200">
              <div className="p-6">
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-rose-50 text-rose-600">
                    <AlertTriangle className="h-5 w-5" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-slate-900 leading-6">
                      {confirmState.title}
                    </h3>
                    <p className="text-xs text-slate-500 leading-relaxed">
                      {confirmState.message}
                    </p>
                  </div>
                </div>
              </div>
              
              <div className="bg-slate-50/80 px-6 py-4 flex flex-row-reverse gap-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={confirmState.onConfirm}
                  className="px-4 py-2 bg-rose-600 hover:bg-rose-700 active:bg-rose-800 text-white rounded-xl text-xs font-bold shadow-xs hover:shadow-sm transition-all cursor-pointer"
                >
                  {confirmState.confirmText || 'Evet'}
                </button>
                <button
                  type="button"
                  onClick={() => setConfirmState(null)}
                  className="px-4 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold transition-all cursor-pointer"
                >
                  {confirmState.cancelText || 'İptal'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating AI Advisor Button */}
      <button
        onClick={() => setIsAiPanelOpen(true)}
        className="fixed bottom-6 right-6 z-45 bg-indigo-600 hover:bg-indigo-700 active:bg-indigo-800 text-white p-4 rounded-full shadow-lg shadow-indigo-200 flex items-center justify-center cursor-pointer transition-all hover:scale-105 active:scale-95 group border border-indigo-500"
        title="AI Finansal Danışman'a Sor"
      >
        <Bot className="w-6 h-6" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs group-hover:ml-2 transition-all duration-300 text-xs font-bold whitespace-nowrap">
          AI Danışman
        </span>
      </button>

      {/* Sliding AI Panel */}
      <AiAdvisorPanel 
        isOpen={isAiPanelOpen}
        onClose={() => setIsAiPanelOpen(false)}
        invoices={invoices}
      />

    </div>
  );
}
