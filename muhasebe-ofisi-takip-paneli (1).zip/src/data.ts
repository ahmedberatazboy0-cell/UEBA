import { Invoice } from './types';

// The current date in the environment is 2026-07-20
export const CURRENT_DATE_STR = '2026-07-20';

// Safely parse an ISO date string (YYYY-MM-DD) into a local Date object without timezone shifts
export function safeParseDate(dateStr: string): Date {
  if (typeof dateStr === 'string' && dateStr.includes('-')) {
    const parts = dateStr.split('-');
    if (parts.length === 3) {
      const year = parseInt(parts[0], 10);
      const month = parseInt(parts[1], 10) - 1;
      const day = parseInt(parts[2], 10);
      return new Date(year, month, day);
    }
  }
  return new Date(dateStr);
}

export const INITIAL_INVOICES: Invoice[] = [
  {
    id: '1',
    companyName: 'ABC Limited',
    amount: 14500.00,
    dueDate: '2026-07-30', // Gelecek (Bekliyor)
    status: 'Bekliyor',
    notes: 'Temmuz ayı danışmanlık faturası',
    createdAt: '2026-07-01'
  },
  {
    id: '2',
    companyName: 'XYZ Danışmanlık',
    amount: 8250.50,
    dueDate: '2026-07-15', // Ödendi (Vadesi geçmişti ama ödendi)
    status: 'Ödendi',
    notes: 'Haziran ayı vergi beyanname bedeli',
    createdAt: '2026-07-01'
  },
  {
    id: '3',
    companyName: 'Güneş İnşaat A.Ş.',
    amount: 32000.00,
    dueDate: '2026-07-10', // Vadesi Geçmiş (2026-07-20'den önce ve Bekliyor)
    status: 'Bekliyor',
    notes: 'KDV Tevkifatı ve beyanname takibi',
    createdAt: '2026-07-01'
  },
  {
    id: '4',
    companyName: 'TeknoBulut Yazılım',
    amount: 5400.00,
    dueDate: '2026-07-22', // Vadesi Yaklaşan (2026-07-20 ile 2026-07-27 arası)
    status: 'Bekliyor',
    notes: 'SGK bildirimleri ve bordrolama',
    createdAt: '2026-07-05'
  },
  {
    id: '5',
    companyName: 'Ege Lojistik Ticaret',
    amount: 19800.00,
    dueDate: '2026-07-26', // Vadesi Yaklaşan
    status: 'Bekliyor',
    notes: 'Ulaştırma beyanları ve defter tutma',
    createdAt: '2026-07-05'
  },
  {
    id: '6',
    companyName: 'Zirve Gıda Sanayi',
    amount: 11200.00,
    dueDate: '2026-07-18', // Vadesi Geçmiş (Bekliyor)
    status: 'Bekliyor',
    notes: 'Stopaj beyannamesi ödemesi',
    createdAt: '2026-07-02'
  },
  {
    id: '7',
    companyName: 'Mavi Yelken Turizm',
    amount: 7500.00,
    dueDate: '2026-07-14', // İptal Edildi
    status: 'İptal Edildi',
    notes: 'Hatalı beyan iptali, yeniden kesilecek',
    createdAt: '2026-07-01'
  },
  {
    id: '8',
    companyName: 'Atlas Mimarlık Hizmetleri',
    amount: 23500.00,
    dueDate: '2026-08-05', // Gelecek faturası
    status: 'Bekliyor',
    notes: 'Proje bazlı vergilendirme danışmanlığı',
    createdAt: '2026-07-15'
  },
  {
    id: '9',
    companyName: 'Özgür Matbaacılık',
    amount: 4100.00,
    dueDate: '2026-07-19', // Ödendi
    status: 'Ödendi',
    notes: 'Defter tasdik ve noter masrafları',
    createdAt: '2026-07-10'
  }
];

// Helper to determine the due status of an invoice
// Returns: 'overdue' (vadesi geçmiş), 'upcoming' (yaklaşan, <= 7 gün), 'normal' (normal), 'paid' (ödendi/iptal)
export function getDueStatus(dueDate: string, status: string): 'overdue' | 'upcoming' | 'normal' | 'paid-cancelled' {
  if (status === 'Ödendi' || status === 'İptal Edildi') {
    return 'paid-cancelled';
  }

  const today = safeParseDate(CURRENT_DATE_STR);
  const due = safeParseDate(dueDate);
  
  // Reset hours to compare dates accurately
  today.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);

  const diffTime = due.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return 'overdue'; // Vadesi geçmiş
  } else if (diffDays >= 0 && diffDays <= 7) {
    return 'upcoming'; // 7 gün veya daha az kalmış (yaklaşan)
  } else {
    return 'normal'; // Daha var
  }
}

// Get helper text/days left info
export function getDaysRemainingText(dueDate: string, status: string): { text: string; colorClass: string; days: number } {
  if (status === 'Ödendi') {
    return { text: 'Ödendi', colorClass: 'text-emerald-600 font-medium', days: 0 };
  }
  if (status === 'İptal Edildi') {
    return { text: 'İptal Edildi', colorClass: 'text-slate-400 line-through', days: 0 };
  }

  const today = safeParseDate(CURRENT_DATE_STR);
  const due = safeParseDate(dueDate);
  today.setHours(0, 0, 0, 0);
  due.setHours(0, 0, 0, 0);

  const diffTime = due.getTime() - today.getTime();
  const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

  if (diffDays < 0) {
    return {
      text: `${Math.abs(diffDays)} gün gecikti`,
      colorClass: 'text-rose-600 font-bold animate-pulse',
      days: diffDays
    };
  } else if (diffDays === 0) {
    return {
      text: 'Bugün son gün!',
      colorClass: 'text-amber-600 font-bold animate-pulse',
      days: diffDays
    };
  } else if (diffDays === 1) {
    return {
      text: 'Yarın vadesi doluyor',
      colorClass: 'text-amber-500 font-semibold',
      days: diffDays
    };
  } else if (diffDays <= 7) {
    return {
      text: `${diffDays} gün kaldı (Yaklaşıyor)`,
      colorClass: 'text-amber-500 font-medium',
      days: diffDays
    };
  } else {
    return {
      text: `${diffDays} gün var`,
      colorClass: 'text-slate-500',
      days: diffDays
    };
  }
}

// Parse CSV content safely
export function parseCSV(csvText: string): Invoice[] {
  const lines = csvText.split('\n');
  const result: Invoice[] = [];
  let idCounter = Date.now();

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;

    // Skip header if it matches keywords
    if (i === 0 && (line.toLowerCase().includes('firma') || line.toLowerCase().includes('tutar') || line.toLowerCase().includes('vade'))) {
      continue;
    }

    const columns = line.split(',').map(col => col.trim());
    if (columns.length < 4) continue;

    const companyName = columns[0];
    const amount = parseFloat(columns[1].replace(/[^0-9.-]/g, '')) || 0;
    const dueDate = columns[2];
    let status = columns[3] as any;

    // Map Turkish terms if necessary, default to Bekliyor
    if (status === 'Ödendi' || status?.toLowerCase() === 'odendi') {
      status = 'Ödendi';
    } else if (status === 'İptal Edildi' || status?.toLowerCase() === 'iptal') {
      status = 'İptal Edildi';
    } else {
      status = 'Bekliyor';
    }

    // Optional payment promise & phone columns
    let promiseDate: string | undefined = undefined;
    let promiseAmount: number | undefined = undefined;
    let phone: string | undefined = undefined;
    
    if (columns.length >= 5 && columns[4]) {
      promiseDate = columns[4];
    }
    if (columns.length >= 6 && columns[5]) {
      const val = parseFloat(columns[5].replace(/[^0-9.-]/g, ''));
      if (!isNaN(val) && val > 0) {
        promiseAmount = val;
      }
    }
    if (columns.length >= 7 && columns[6]) {
      phone = columns[6];
    }

    const notes = columns.length >= 8 ? columns[7] : 'CSV ile aktarıldı';

    if (companyName && dueDate) {
      result.push({
        id: `csv-${idCounter++}`,
        companyName,
        amount,
        dueDate,
        status,
        notes: notes || undefined,
        createdAt: CURRENT_DATE_STR,
        promiseDate,
        promiseAmount,
        phone
      });
    }
  }

  return result;
}

// Export invoices to CSV format
export function exportToCSV(invoices: Invoice[]): string {
  const header = 'Firma Adi, Tutar, Vade Tarihi, Durum, Odeme Sozu Tarihi, Soz Verilen Tutar, Telefon, Aciklama\n';
  const rows = invoices.map(inv => {
    // Escape commas
    const name = inv.companyName.replace(/,/g, ' ');
    const notes = (inv.notes || '').replace(/,/g, ' ');
    const pDate = inv.promiseDate || '';
    const pAmount = inv.promiseAmount ? inv.promiseAmount.toFixed(2) : '';
    const phoneNo = inv.phone || '';
    return `${name}, ${inv.amount.toFixed(2)}, ${inv.dueDate}, ${inv.status}, ${pDate}, ${pAmount}, ${phoneNo}, ${notes}`;
  }).join('\n');
  return header + rows;
}
