export type InvoiceStatus = 'Bekliyor' | 'Ödendi' | 'İptal Edildi';

export interface Invoice {
  id: string;
  companyName: string;
  amount: number;
  dueDate: string;
  status: InvoiceStatus;
  notes?: string;
  createdAt: string;
  promiseDate?: string; // Ödeme Sözü Tarihi
  promiseAmount?: number; // Söz Verilen Tutar
  phone?: string; // Telefon Numarası
}

export interface DashboardStats {
  totalAmount: number;
  paidAmount: number;
  pendingAmount: number;
  overdueCount: number;
  upcomingCount: number;
  pendingCount: number;
}

export type DueFilterType = 'hepsi' | 'vadesi-gecen' | 'vadesi-yaklasan' | 'vadesi-gelen';
export type StatusFilterType = 'hepsi' | 'Bekliyor' | 'Ödendi' | 'İptal Edildi';

export interface FilterOptions {
  search: string;
  status: StatusFilterType;
  dueStatus: DueFilterType;
  minAmount: string;
  maxAmount: string;
  sortBy: 'dueDate-asc' | 'dueDate-desc' | 'amount-asc' | 'amount-desc' | 'companyName-asc';
}
